package com.example.dishantsinghyadav.menuapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d(TAG, "onCreate: Started.");


    }

    /*
     *
     * onCreateOptionsMenu() is created to inflate the menu is MainActivity.
     *
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        Log.d(TAG, "onCreateOptionsMenu: Started.");

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu); // inflater inflates the menu layout.
        return true;
    }

    /*
     *
     * onOptionsItemSelected() is the listener of all the items in the options menu and performs
     * desired action based on which item is clicked.
     *
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId(); //id object stores the "id" of the items present in the optionsMenu.

        if (id == R.id.second_item){
            Log.d(TAG, "onOptionsItemSelected: Second Item clicked.");

            Toast.makeText(this, "Colour is changed to Red", Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(this, red.class); //When you click the second item, it transfers to "Red" activity.
            startActivity(intent);
        }
        else if (id == R.id.third_item){
            Log.d(TAG, "onOptionsItemSelected: Third item clicked.");

            Toast.makeText(this, "Colour is changed to Blue", Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(this, blue.class);  //When you click the second item, it transfers to "Blue" activity.
            startActivity(intent);
        }
        else if (id == R.id.fourth_item){
            Log.d(TAG, "onOptionsItemSelected: Fourth item clicked.");

            Toast.makeText(this, "Colour is changed to Yellow", Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(this, yellow.class);  //When you click the second item, it transfers to "Yellow" activity.
            startActivity(intent);
        }

        return true;
    }
}